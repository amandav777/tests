<?php
use PHPUnit\Framework\TestCase;

require_once 'CalculadoraFinanceira.php';

class CalculadoraFinanceiraTest extends TestCase
{
    protected $calculadora;

    protected function setUp(): void
    {
        $this->calculadora = new CalculadoraFinanceira();
    }

    // Testes para calcularValorFuturo
    public function testCalcularValorFuturo_ValoresPositivos()
    {
        $resultado = $this->calculadora->calcularValorFuturo(1000, 0.05, 10);
        $esperado = 1000 * pow(1 + 0.05, 10);
        $this->assertEquals($esperado, $resultado);
    }

    public function testCalcularValorFuturo_TaxaDeJurosNegativa()
    {
        $this->expectException(InvalidArgumentException::class);
        $this->calculadora->calcularValorFuturo(1000, -0.05, 10);
    }

    public function testCalcularValorFuturo_PeriodoZero()
    {
        $this->expectException(InvalidArgumentException::class);
        $this->calculadora->calcularValorFuturo(1000, 0.05, 0);
    }

    // Testes para calcularPagamentoEmpréstimo
    public function testCalcularPagamentoEmpréstimo_ValoresPositivos()
    {
        $resultado = $this->calculadora->calcularPagamentoEmpréstimo(10000, 0.05, 60);
        $taxaMensal = 0.05 / 12;
        $esperado = (10000 * $taxaMensal) / (1 - pow(1 + $taxaMensal, -60));
        $this->assertEquals($esperado, $resultado);
    }

    public function testCalcularPagamentoEmpréstimo_PeriodoNegativo()
    {
        $this->expectException(InvalidArgumentException::class);
        $this->calculadora->calcularPagamentoEmpréstimo(10000, 0.05, -60);
    }

    // Testes para calcularTaxaDeRetorno
    public function testCalcularTaxaDeRetorno_ValorFinalMaiorQueInicial()
    {
        $resultado = $this->calculadora->calcularTaxaDeRetorno(1000, 1500, 5);
        $esperado = pow(1500 / 1000, 1 / 5) - 1;
        $this->assertEquals($esperado, $resultado);
    }

    public function testCalcularTaxaDeRetorno_ValorInicialIgualAoFinal()
    {
        $resultado = $this->calculadora->calcularTaxaDeRetorno(1000, 1000, 5);
        $this->assertEquals(0, $resultado);
    }

    public function testCalcularTaxaDeRetorno_ValorFinalMenorQueInicial()
    {
        $resultado = $this->calculadora->calcularTaxaDeRetorno(1500, 1000, 5);
        $esperado = pow(1000 / 1500, 1 / 5) - 1;
        $this->assertEquals($esperado, $resultado);
    }

    // Testes para calcularPeriodoParaDuplicar
    public function testCalcularPeriodoParaDuplicar_TaxaNormal()
    {
        $resultado = $this->calculadora->calcularPeriodoParaDuplicar(0.1);
        $esperado = log(2) / log(1 + 0.1);
        $this->assertEquals($esperado, $resultado);
    }

    public function testCalcularPeriodoParaDuplicar_TaxaExtremamenteBaixa()
    {
        $resultado = $this->calculadora->calcularPeriodoParaDuplicar(0.001);
        $esperado = log(2) / log(1 + 0.001);
        $this->assertEquals($esperado, $resultado);
    }

    // Testes para valores inválidos
    public function testCalcularValorFuturo_ValorPresenteNegativo()
    {
        $this->expectException(InvalidArgumentException::class);
        $this->calculadora->calcularValorFuturo(-1000, 0.05, 10);
    }

    public function testCalcularPagamentoAnuidade_ValoresInvalidos()
    {
        $this->expectException(InvalidArgumentException::class);
        $this->calculadora->calcularPagamentoAnuidade(-1000, 0.05, 10);
    }

    public function testCalcularTaxaEfetivaAnual_ValoresInvalidos()
    {
        $this->expectException(InvalidArgumentException::class);
        $this->calculadora->calcularTaxaEfetivaAnual(-0.05, 12);
    }

    // Testes de comparação entre valor presente e valor futuro
    public function testCompararValorPresenteValorFuturo()
    {
        $valorPresente = 1000;
        $taxaDeJuros = 0.05;
        $periodos = 10;
        $valorFuturo = $this->calculadora->calcularValorFuturo($valorPresente, $taxaDeJuros, $periodos);
        $valorPresenteCalculado = $this->calculadora->calcularValorPresente($valorFuturo, $taxaDeJuros, $periodos);
        $this->assertEquals($valorPresente, $valorPresenteCalculado);
    }
}
